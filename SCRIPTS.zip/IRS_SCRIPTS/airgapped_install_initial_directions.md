# Airgapped

The following is an example `/etc/replicated.conf` suitable for an automated airgapped install, which builds on the online example above. Note the addition of `LicenseBootstrapAirgapPackagePath`, which is a path to the `.airgap` bundle on the instance.

```conf
{
    "DaemonAuthenticationType":          "password",
    "DaemonAuthenticationPassword":      "your-password-here",
    "TlsBootstrapType":                  "server-path",
    "TlsBootstrapHostname":              "server.company.com",
    "TlsBootstrapCert":                  "/etc/server.crt",
    "TlsBootstrapKey":                   "/etc/server.key",
    "BypassPreflightChecks":             true,
    "ImportSettingsFrom":                "/path/to/settings.json",
    "LicenseFileLocation":               "/path/to/license.rli",
    "LicenseBootstrapAirgapPackagePath": "/path/to/bundle.airgap"
}
```

### Invoking the airgap installation script

Following on from the [manual airgapped](https://developer.hashicorp.com/terraform/enterprise/install/interactive/installer#run-the-installer-airgapped) install steps, you must also have the installer bootstrapper already on the instance. For illustrative purposes, it is assumed the installer bootstrapper has been unarchived in `/tmp`.

Once `/etc/replicated.conf` has been created, you can now execute the install script as root:

```sh
cd /tmp
./install.sh \
    airgap \
    no-proxy \
    private-address=1.2.3.4 \
    public-address=5.6.7.8
```
**Note:** The ./install.sh script must be executed from the directory in which it is placed.

## Waiting for Terraform Enterprise to become ready

Once the installer finishes, you may poll the /_health_check endpoint until a 200 is returned by the application, indicating that it is fully started:

```sh
while ! curl -ksfS --connect-timeout 5 https://tfe.example.com/_health_check; do
    sleep 5
done
```

## If the installation does not appear to be configured correctly

If the installation script (install.sh) exits successfully, but the Replicated web UI prompts for additional configuration rather than skipping that step, it's likely that the supplied configuration files were not applied during installation.

- Verify the locations and permissions of the files. The Replicated configuration file should be placed in `/etc/replicated.conf`, and the application settings file should be placed in the path specified in the Replicated configuration file. The permissions of both files should be 600 if owned by the replicated user, or 644.
- Run a JSON validator on the files to check their validity.
- After resolving any issues with file validity or permissions, run the following commands to reload your configuration:

**Important:** These commands are only for fixing a new installation. Do not run these commands on an existing installation, as they will destroy important data.

```sh
sudo systemctl stop replicated replicated-ui replicated-operator
sudo rm -rf /var/lib/replicated
sudo systemctl start replicated replicated-ui replicated-operator
```

References

[Replicated installer flags](https://help.replicated.com/docs/native/customer-installations/installing-via-script/#flags)

[/etc/replicated.conf](https://help.replicated.com/docs/native/customer-installations/automating/#configure-replicated-automatically)

[application settings](https://help.replicated.com/docs/native/customer-installations/automating/#configure-replicated-automatically)